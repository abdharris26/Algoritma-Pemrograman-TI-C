buku = [
    ["Algoritma", 2000],
    ["Basis Data", 2500],
    ["struktur data", 3000],
    ["python", 3500],
    ["sejarah", 4000]
]