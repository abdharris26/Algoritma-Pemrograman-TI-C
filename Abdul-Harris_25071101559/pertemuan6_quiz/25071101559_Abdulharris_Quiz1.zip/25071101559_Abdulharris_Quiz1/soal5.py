class buku:
    def __init__(self, judul, denda_per_hari):
        self.judul = judul
        self.denda_per_hari = denda_per_hari
    def tampilkan(self):
        print(self.judul, self.denda_per_hari)   
        
class peminjaman:
    def __init__(self, buku, hari_terlambat):
        self.buku = buku
        self.hari_terlambat = hari_terlambat
        
buku1 = buku("sejarah",2000)