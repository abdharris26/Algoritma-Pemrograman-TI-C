buku = [
    ["Algoritma", 2000],
    ["Basis Data", 2500],
    ["struktur data", 3000],
    ["python", 3500],
    ["sejarah", 4000]
]

meminjam = []

while True:
    for i in range(len(buku)):
        print (i+1, buku[i][0], buku[i][1])
        
    pilih = int(input("pilihlah buku yang di inginkan(0 selesai): "))
    
    if pilih == 0:
        break
    
    if 1 <= pilih <= len(buku):
        jumlah = int(input("jumlah meminjam buku: "))
        meminjam.append([buku[pilih-1][0], buku[pilih-1][1], jumlah])
    else:
        print("buku tidak valid")
        
print("daftar")      
total = 0

for item in meminjam:
    semua_buku = item[1] * item[2]
    total += semua_buku
    print(buku[0], buku[2], "=",semua_buku)

print("denda yang harus di bayar: ", total  )